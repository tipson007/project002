﻿namespace FileProcessing
{
    partial class FileOperations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.searchDirTextBox = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnSort = new System.Windows.Forms.Button();
            this.resultListView = new System.Windows.Forms.ListView();
            this.File = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sortedFile = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnRb4Search = new System.Windows.Forms.Button();
            this.lblRb4Search = new System.Windows.Forms.Label();
            this.txtRb4Search = new System.Windows.Forms.TextBox();
            this.btnRb2Serach = new System.Windows.Forms.Button();
            this.btnRb2Browse = new System.Windows.Forms.Button();
            this.txtRb2SearchDir = new System.Windows.Forms.TextBox();
            this.lblRb2Search = new System.Windows.Forms.Label();
            this.listSearchResults = new System.Windows.Forms.ListView();
            this.rdSearchFiles = new System.Windows.Forms.RadioButton();
            this.rbAllSorFilesForAllDir = new System.Windows.Forms.RadioButton();
            this.rbAllSorFilesForDir = new System.Windows.Forms.RadioButton();
            this.rbAllSortedDir = new System.Windows.Forms.RadioButton();
            this.btnCalc = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Directory";
            //this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // searchDirTextBox
            // 
            this.searchDirTextBox.Location = new System.Drawing.Point(133, 25);
            this.searchDirTextBox.Name = "searchDirTextBox";
            this.searchDirTextBox.Size = new System.Drawing.Size(112, 20);
            this.searchDirTextBox.TabIndex = 1;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(251, 23);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(29, 23);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "....";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "fileChooseDir";
            // 
            // btnSort
            // 
            this.btnSort.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSort.Location = new System.Drawing.Point(286, 23);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(75, 23);
            this.btnSort.TabIndex = 3;
            this.btnSort.Text = "Sort";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // resultListView
            // 
            this.resultListView.Activation = System.Windows.Forms.ItemActivation.TwoClick;
            this.resultListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.File,
            this.sortedFile});
            this.resultListView.FullRowSelect = true;
            this.resultListView.Location = new System.Drawing.Point(53, 97);
            this.resultListView.MultiSelect = false;
            this.resultListView.Name = "resultListView";
            this.resultListView.Size = new System.Drawing.Size(325, 376);
            this.resultListView.TabIndex = 9;
            this.resultListView.UseCompatibleStateImageBehavior = false;
            this.resultListView.View = System.Windows.Forms.View.Details;
            // 
            // File
            // 
            this.File.Text = "File";
            this.File.Width = 104;
            // 
            // sortedFile
            // 
            this.sortedFile.Text = "Output File";
            this.sortedFile.Width = 260;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnRb4Search);
            this.groupBox1.Controls.Add(this.lblRb4Search);
            this.groupBox1.Controls.Add(this.txtRb4Search);
            this.groupBox1.Controls.Add(this.btnRb2Serach);
            this.groupBox1.Controls.Add(this.btnRb2Browse);
            this.groupBox1.Controls.Add(this.txtRb2SearchDir);
            this.groupBox1.Controls.Add(this.lblRb2Search);
            this.groupBox1.Controls.Add(this.listSearchResults);
            this.groupBox1.Controls.Add(this.rdSearchFiles);
            this.groupBox1.Controls.Add(this.rbAllSorFilesForAllDir);
            this.groupBox1.Controls.Add(this.rbAllSorFilesForDir);
            this.groupBox1.Controls.Add(this.rbAllSortedDir);
            this.groupBox1.Location = new System.Drawing.Point(378, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(790, 447);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Actions";
            // 
            // btnRb4Search
            // 
            this.btnRb4Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRb4Search.Location = new System.Drawing.Point(702, 92);
            this.btnRb4Search.Name = "btnRb4Search";
            this.btnRb4Search.Size = new System.Drawing.Size(75, 23);
            this.btnRb4Search.TabIndex = 17;
            this.btnRb4Search.Text = "Search";
            this.btnRb4Search.UseVisualStyleBackColor = true;
            this.btnRb4Search.Visible = false;
            this.btnRb4Search.Click += new System.EventHandler(this.btnRb4Search_Click);
            // 
            // lblRb4Search
            // 
            this.lblRb4Search.AutoSize = true;
            this.lblRb4Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRb4Search.Location = new System.Drawing.Point(333, 97);
            this.lblRb4Search.Name = "lblRb4Search";
            this.lblRb4Search.Size = new System.Drawing.Size(110, 13);
            this.lblRb4Search.TabIndex = 16;
            this.lblRb4Search.Text = "Enter search word";
            this.lblRb4Search.Visible = false;
            // 
            // txtRb4Search
            // 
            this.txtRb4Search.Location = new System.Drawing.Point(449, 94);
            this.txtRb4Search.Name = "txtRb4Search";
            this.txtRb4Search.Size = new System.Drawing.Size(247, 20);
            this.txtRb4Search.TabIndex = 15;
            this.txtRb4Search.Visible = false;
            // 
            // btnRb2Serach
            // 
            this.btnRb2Serach.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRb2Serach.Location = new System.Drawing.Point(702, 49);
            this.btnRb2Serach.Name = "btnRb2Serach";
            this.btnRb2Serach.Size = new System.Drawing.Size(75, 23);
            this.btnRb2Serach.TabIndex = 14;
            this.btnRb2Serach.Text = "Search";
            this.btnRb2Serach.UseVisualStyleBackColor = true;
            this.btnRb2Serach.Visible = false;
            this.btnRb2Serach.Click += new System.EventHandler(this.btnRb2Serach_Click);
            // 
            // btnRb2Browse
            // 
            this.btnRb2Browse.Location = new System.Drawing.Point(667, 49);
            this.btnRb2Browse.Name = "btnRb2Browse";
            this.btnRb2Browse.Size = new System.Drawing.Size(29, 23);
            this.btnRb2Browse.TabIndex = 13;
            this.btnRb2Browse.Text = "....";
            this.btnRb2Browse.UseVisualStyleBackColor = true;
            this.btnRb2Browse.Visible = false;
            this.btnRb2Browse.Click += new System.EventHandler(this.btnRb2Browse_Click);
            // 
            // txtRb2SearchDir
            // 
            this.txtRb2SearchDir.Location = new System.Drawing.Point(521, 51);
            this.txtRb2SearchDir.Name = "txtRb2SearchDir";
            this.txtRb2SearchDir.Size = new System.Drawing.Size(140, 20);
            this.txtRb2SearchDir.TabIndex = 12;
            this.txtRb2SearchDir.Visible = false;
            // 
            // lblRb2Search
            // 
            this.lblRb2Search.AutoSize = true;
            this.lblRb2Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRb2Search.Location = new System.Drawing.Point(426, 52);
            this.lblRb2Search.Name = "lblRb2Search";
            this.lblRb2Search.Size = new System.Drawing.Size(98, 13);
            this.lblRb2Search.TabIndex = 11;
            this.lblRb2Search.Text = "Select Directory";
            this.lblRb2Search.Visible = false;
            // 
            // listSearchResults
            // 
            this.listSearchResults.Activation = System.Windows.Forms.ItemActivation.TwoClick;
            this.listSearchResults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listSearchResults.FullRowSelect = true;
            this.listSearchResults.Location = new System.Drawing.Point(6, 121);
            this.listSearchResults.MultiSelect = false;
            this.listSearchResults.Name = "listSearchResults";
            this.listSearchResults.Size = new System.Drawing.Size(778, 320);
            this.listSearchResults.TabIndex = 10;
            this.listSearchResults.UseCompatibleStateImageBehavior = false;
            this.listSearchResults.View = System.Windows.Forms.View.Details;
            // 
            // rdSearchFiles
            // 
            this.rdSearchFiles.AutoSize = true;
            this.rdSearchFiles.Location = new System.Drawing.Point(6, 95);
            this.rdSearchFiles.Name = "rdSearchFiles";
            this.rdSearchFiles.Size = new System.Drawing.Size(115, 17);
            this.rdSearchFiles.TabIndex = 3;
            this.rdSearchFiles.TabStop = true;
            this.rdSearchFiles.Text = "Search sorted files ";
            this.rdSearchFiles.UseVisualStyleBackColor = true;
            this.rdSearchFiles.CheckedChanged += new System.EventHandler(this.rdSearchFiles_CheckedChanged);
            // 
            // rbAllSorFilesForAllDir
            // 
            this.rbAllSorFilesForAllDir.AutoSize = true;
            this.rbAllSorFilesForAllDir.Location = new System.Drawing.Point(6, 72);
            this.rbAllSorFilesForAllDir.Name = "rbAllSorFilesForAllDir";
            this.rbAllSorFilesForAllDir.Size = new System.Drawing.Size(264, 17);
            this.rbAllSorFilesForAllDir.TabIndex = 2;
            this.rbAllSorFilesForAllDir.TabStop = true;
            this.rbAllSorFilesForAllDir.Text = "List all files that have been sorted for all directories.";
            this.rbAllSorFilesForAllDir.UseVisualStyleBackColor = true;
            this.rbAllSorFilesForAllDir.CheckedChanged += new System.EventHandler(this.rbAllSorFilesForAllDir_CheckedChanged);
            // 
            // rbAllSorFilesForDir
            // 
            this.rbAllSorFilesForDir.AutoSize = true;
            this.rbAllSorFilesForDir.Location = new System.Drawing.Point(6, 49);
            this.rbAllSorFilesForDir.Name = "rbAllSorFilesForDir";
            this.rbAllSorFilesForDir.Size = new System.Drawing.Size(278, 17);
            this.rbAllSorFilesForDir.TabIndex = 1;
            this.rbAllSorFilesForDir.TabStop = true;
            this.rbAllSorFilesForDir.Text = "List all files that have been sorted for a given directory";
            this.rbAllSorFilesForDir.UseVisualStyleBackColor = true;
            this.rbAllSorFilesForDir.CheckedChanged += new System.EventHandler(this.rbAllSorFilesForDir_CheckedChanged);
            // 
            // rbAllSortedDir
            // 
            this.rbAllSortedDir.AutoSize = true;
            this.rbAllSortedDir.Location = new System.Drawing.Point(6, 26);
            this.rbAllSortedDir.Name = "rbAllSortedDir";
            this.rbAllSortedDir.Size = new System.Drawing.Size(247, 17);
            this.rbAllSortedDir.TabIndex = 0;
            this.rbAllSortedDir.TabStop = true;
            this.rbAllSortedDir.Text = "List all directories that have had text files sorted";
            this.rbAllSortedDir.UseVisualStyleBackColor = true;
            this.rbAllSortedDir.CheckedChanged += new System.EventHandler(this.rbAllSortedDir_CheckedChanged);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(251, 52);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(110, 26);
            this.btnCalc.TabIndex = 11;
            this.btnCalc.Text = "Calc";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Visible = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(123, 58);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(122, 17);
            this.checkBox1.TabIndex = 12;
            this.checkBox1.Text = "Evalute Caluclations";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1174, 484);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.resultListView);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.searchDirTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            //this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox searchDirTextBox;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.ListView resultListView;
        private System.Windows.Forms.ColumnHeader File;
        private System.Windows.Forms.ColumnHeader sortedFile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListView listSearchResults;
        private System.Windows.Forms.RadioButton rdSearchFiles;
        private System.Windows.Forms.RadioButton rbAllSorFilesForAllDir;
        private System.Windows.Forms.RadioButton rbAllSorFilesForDir;
        private System.Windows.Forms.RadioButton rbAllSortedDir;
        private System.Windows.Forms.Label lblRb4Search;
        private System.Windows.Forms.TextBox txtRb4Search;
        private System.Windows.Forms.Button btnRb2Serach;
        private System.Windows.Forms.Button btnRb2Browse;
        private System.Windows.Forms.TextBox txtRb2SearchDir;
        private System.Windows.Forms.Label lblRb2Search;
        private System.Windows.Forms.Button btnRb4Search;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

