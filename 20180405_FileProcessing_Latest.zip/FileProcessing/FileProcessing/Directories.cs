﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessing
{
    public class Directories
    {
        public string Directory { get; set; }
        public List<KeyValuePair<string, string>> Files { get; set; }
    }
}
