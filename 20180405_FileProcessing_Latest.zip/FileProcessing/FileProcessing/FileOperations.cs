﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileProcessing
{
    public partial class FileOperations : Form
    {
        public static List<Directories> DirectoriesList = new List<Directories>();

        public FileOperations()
        {
            InitializeComponent();
        }

        #region FormEvents
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.SelectedPath = searchDirTextBox.Text;
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                searchDirTextBox.Text = dlg.SelectedPath;
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            try
            {
                DirectoryInfo dinfo = new DirectoryInfo(searchDirTextBox.Text);
                FileInfo[] Files = dinfo.GetFiles("*.txt");

                this.resultListView.Items.Clear();
                foreach (FileInfo file in Files)
                {
                    var sortedFileName = string.Format(@"{0}{1}", "sorted", file.Name);
                    var sortedFilePath = Path.Combine(dinfo.FullName, "SortedFiles", sortedFileName);

                    if (!Directory.Exists(sortedFilePath))
                    {
                        if (!Directory.Exists(Path.Combine(dinfo.FullName, "SortedFiles")))
                            Directory.CreateDirectory(Path.Combine(dinfo.FullName, "SortedFiles"));

                        ProcessFileSortByWord(Path.Combine(dinfo.FullName, file.Name), sortedFilePath, dinfo.FullName);

                        resultListView.Items.Add(new ListViewItem(new string[] { file.Name, sortedFileName }));
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, string.Format("Exception details:\n{0}", ex), string.Format("Exception '{0}' occurred.", ex.GetType()), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }        

        private void rbAllSortedDir_CheckedChanged(object sender, EventArgs e)
        {
            btnRb4Search.Visible = false;
            lblRb4Search.Visible = false;
            txtRb4Search.Visible = false;
            lblRb2Search.Visible = false;
            txtRb2SearchDir.Visible = false;
            btnRb2Browse.Visible = false;
            btnRb2Serach.Visible = false;

            ResetSearchResultListView();

            ColumnHeader directoryHeader = new ColumnHeader();
            directoryHeader.Text = "Directiry";
            directoryHeader.Width = 400;
            ColumnHeader sortedDirectoryHeader = new ColumnHeader();
            sortedDirectoryHeader.Text = "Sorted Directiry";
            sortedDirectoryHeader.Width = 400;
            listSearchResults.Columns.Add(directoryHeader);
            listSearchResults.Columns.Add(sortedDirectoryHeader);

            var directories = DirectoriesList.Select(m => m.Directory).ToArray();
            listSearchResults.ShowItemToolTips = true;
            foreach (var directory in directories)
                listSearchResults.Items.Add(new ListViewItem(new string[] { directory, directory + "/SortedFiles" }));
        }

        private void rbAllSorFilesForDir_CheckedChanged(object sender, EventArgs e)
        {
            lblRb2Search.Visible = true;
            txtRb2SearchDir.Visible = true;
            btnRb2Browse.Visible = true;
            btnRb2Serach.Visible = true;

            btnRb4Search.Visible = false;
            lblRb4Search.Visible = false;
            txtRb4Search.Visible = false;

            ResetSearchResultListView();

            ColumnHeader directoryHeader = new ColumnHeader();
            directoryHeader.Text = "File";
            directoryHeader.Width = 400;
            ColumnHeader sortedDirectoryHeader = new ColumnHeader();
            sortedDirectoryHeader.Text = "Sorted File";
            sortedDirectoryHeader.Width = 400;
            listSearchResults.Columns.Add(directoryHeader);
            listSearchResults.Columns.Add(sortedDirectoryHeader);

        }

        private void rbAllSorFilesForAllDir_CheckedChanged(object sender, EventArgs e)
        {
            btnRb4Search.Visible = false;
            lblRb4Search.Visible = false;
            txtRb4Search.Visible = false;
            lblRb2Search.Visible = false;
            txtRb2SearchDir.Visible = false;
            btnRb2Browse.Visible = false;
            btnRb2Serach.Visible = false;

            ResetSearchResultListView();

            ColumnHeader directoryHeader = new ColumnHeader();
            directoryHeader.Text = "File";
            directoryHeader.Width = 400;
            ColumnHeader sortedDirectoryHeader = new ColumnHeader();
            sortedDirectoryHeader.Text = "Sorted File";
            sortedDirectoryHeader.Width = 400;
            listSearchResults.Columns.Add(directoryHeader);
            listSearchResults.Columns.Add(sortedDirectoryHeader);

            var searchedFiles = DirectoriesList.Select(m => m.Files).ToList();
            foreach (var searchedFile in searchedFiles)
                foreach (var file in searchedFile)
                    listSearchResults.Items.Add(new ListViewItem(new string[] { file.Key, file.Value.ToString() }));

        }

        private void rdSearchFiles_CheckedChanged(object sender, EventArgs e)
        {
            lblRb2Search.Visible = false;
            txtRb2SearchDir.Visible = false;
            btnRb2Browse.Visible = false;
            btnRb2Serach.Visible = false;

            btnRb4Search.Visible = true;
            lblRb4Search.Visible = true;
            txtRb4Search.Visible = true;

        }

        private void btnRb2Serach_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRb2SearchDir.Text))
            {
                try
                {
                    ResetSearchResultListView();

                    ColumnHeader directoryHeader = new ColumnHeader();
                    directoryHeader.Text = "File";
                    directoryHeader.Width = 400;
                    ColumnHeader sortedDirectoryHeader = new ColumnHeader();
                    sortedDirectoryHeader.Text = "Sorted File";
                    sortedDirectoryHeader.Width = 400;
                    listSearchResults.Columns.Add(directoryHeader);
                    listSearchResults.Columns.Add(sortedDirectoryHeader);

                    var searchedFiles = DirectoriesList.FirstOrDefault(m => m.Directory.Equals(txtRb2SearchDir.Text)).Files;
                    foreach (var searchedFile in searchedFiles)
                        listSearchResults.Items.Add(new ListViewItem(new string[] { searchedFile.Key, searchedFile.Value.ToString() }));
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void btnRb4Search_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRb4Search.Text))
            {
                ResetSearchResultListView();
                ColumnHeader directoryHeader = new ColumnHeader();
                directoryHeader.Text = "File";
                directoryHeader.Width = 400;
                ColumnHeader sortedDirectoryHeader = new ColumnHeader();
                sortedDirectoryHeader.Text = "Word Count";
                sortedDirectoryHeader.Width = 400;
                listSearchResults.Columns.Add(directoryHeader);
                listSearchResults.Columns.Add(sortedDirectoryHeader);

                var directories = DirectoriesList.Select(m => m.Directory).ToArray();
                foreach (var directory in directories)
                {
                    DirectoryInfo dinfo = new DirectoryInfo(directory + "/SortedFiles");
                    FileInfo[] allFiles = dinfo.GetFiles("*.txt");

                    foreach (var file in allFiles)
                    {
                        var sortedFileName = file.Name;
                        var sortedFilePath = Path.Combine(dinfo.FullName, sortedFileName);
                        string contents = System.IO.File.ReadAllText(sortedFilePath);
                        var actualCount = "1";
                        Regex r2 = new Regex(string.Format(@"(?<={0},\s)-?\d+", Regex.Escape(txtRb4Search.Text.Trim().Replace(",", ""))));
                        MatchCollection matches2 = r2.Matches(contents);
                        if (matches2.Count > 0)
                            actualCount = matches2[0].Value;

                        if (contents.Contains(txtRb4Search.Text.Trim().Replace(",", "")))
                        {
                            listSearchResults.Items.Add(new ListViewItem(new string[] { sortedFilePath, actualCount }));
                        }
                    }
                }
            }
        }        

        private void btnRb2Browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.SelectedPath = searchDirTextBox.Text;
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                txtRb2SearchDir.Text = dlg.SelectedPath;
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                DirectoryInfo dinfo = new DirectoryInfo(searchDirTextBox.Text);
                FileInfo[] Files = dinfo.GetFiles("*.calc");
                this.resultListView.Items.Clear();

                // Create Directory for Output File
                var currentTime = DateTime.Now;
                var answPutFileName = string.Format(@"{0}{1}", currentTime.ToString("yyyy/MM/dd HH-mm-ss"), ".answ");
                var answerOutputFilePath = Path.Combine(dinfo.FullName, "Output", answPutFileName);
                if (!Directory.Exists(answerOutputFilePath))
                    if (!Directory.Exists(Path.Combine(dinfo.FullName, "Output")))
                        Directory.CreateDirectory(Path.Combine(dinfo.FullName, "Output"));

                foreach (FileInfo file in Files)
                {
                    ProcessMathCaluclations(Path.Combine(dinfo.FullName, file.Name), answerOutputFilePath, dinfo.FullName);
                    this.resultListView.Items.Add(new ListViewItem(new string[] { file.Name, answPutFileName }));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, string.Format("Exception details:\n{0}", ex), string.Format("Exception '{0}' occurred.", ex.GetType()), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                btnCalc.Visible = true;
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Process the .txt file and writes sorted words to output fles
        /// </summary>
        /// <param name="orgFilePath">Selected file</param>
        /// <param name="sortedFilePath">sorted output file</param>
        /// <param name="directory">Choosen directory</param>
        private void ProcessFileSortByWord(string orgFilePath, string sortedFilePath, string directory)
        {
            var list = new List<KeyValuePair<string, string>>();
            var pair = new KeyValuePair<string, string>(orgFilePath, sortedFilePath);
            if (DirectoriesList.Where(m => m.Directory.Equals(directory)).ToList().Count == 0)
            {

                list.Add(pair);
                DirectoriesList.Add(new Directories
                {
                    Directory = directory,
                    Files = list
                });
            }
            else
            {
                DirectoriesList.FirstOrDefault(m => m.Directory.Equals(directory)).Files.Add(pair);
            }


            using (FileStream fs = new FileStream(sortedFilePath, FileMode.OpenOrCreate))
            {
                using (TextWriter tw = new StreamWriter(fs, Encoding.ASCII))
                {
                    string s = System.IO.File.ReadAllText(orgFilePath, Encoding.ASCII);
                    string[] words = s.Split(new char[] { ' ', '\r', '\n', ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string word in SortWords(words))
                        if (!string.IsNullOrEmpty(word.Trim()))
                            tw.WriteLine(word.Trim());
                }
            }
        }

        /// <summary>
        /// Process the .Calc file and writes the result to output file
        /// </summary>
        /// <param name="orgFilePath">file path</param>
        /// <param name="answerFilePath">.answ file path</param>
        /// <param name="directory">selected directory</param>
        private void ProcessMathCaluclations(string orgFilePath, string answerFilePath, string directory)
        {
            using (FileStream fs = new FileStream(answerFilePath, FileMode.Append))
            {
                using (TextWriter tw = new StreamWriter(fs, Encoding.ASCII))
                {
                    string contents = System.IO.File.ReadAllText(orgFilePath, Encoding.ASCII);
                    string[] mathExpressions = contents.Split(new char[] { ' ', '\r', '\n', ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string mathExpression in mathExpressions)
                        if (MathsEvaluator.IsExpression(mathExpression))
                        {
                            decimal d;
                            if (MathsEvaluator.TryParse(mathExpression, out d))
                                tw.WriteLine(mathExpression + "=" + MathsEvaluator.Parse(mathExpression));
                        }
                    tw.WriteLine();
                }
            }
        }

        /// <summary>
        /// Sort the String Array List in AlphaNumeric Order
        /// </summary>
        /// <param name="words">String array to be sorted</param>
        /// <returns></returns>
        private string[] SortWords(string[] words)
        {
            var sortedWords = words
                .GroupBy(word => word)
                .Select(group => group.Count() > 1 ? group.Key + ", " + group.Count() : group.Key)
                .OrderBy(g => g)
                .ToArray();
            Array.Sort(sortedWords, new AlphanumComparatorFast());
            return sortedWords;
        }

        /// <summary>
        /// Reset the Result window to initial mode.
        /// </summary>
        private void ResetSearchResultListView()
        {
            this.listSearchResults.Items.Clear();
            var coloumnsCount = listSearchResults.Columns.Count;
            for (var i = 0; i < coloumnsCount; i++)
            {
                listSearchResults.Columns.RemoveAt(0);
            }
        }

        #endregion
    }
}
