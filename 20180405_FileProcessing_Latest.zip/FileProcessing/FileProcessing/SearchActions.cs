﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessing
{
    public static class SearchActions
    {
        public static List<KeyValuePair<string, string>> SearchedDirectories { get; set; }
        public static List<KeyValuePair<string, string>> SearchedFiles { get; set; }

        /// <summary>
        /// Get the all directories for which files have been sorted
        /// </summary>
        /// <returns></returns>
        public static List<KeyValuePair<string, string>> ListAllDirectories()
        {
            return SearchedDirectories;
        }

        /// <summary>
        /// Get the all sorted files for a choosen directory.
        /// </summary>
        /// <param name="directoryPath"></param>
        /// <returns></returns>
        public static List<KeyValuePair<string, string>> ListAllSortedFiles(string directoryPath)
        {
            return new List<KeyValuePair<string, string>>();
        }

        /// <summary>
        /// Get the all sorted files
        /// </summary>
        /// <returns></returns>
        public static List<KeyValuePair<string, string>> ListAllSortedFiles()
        {
            return SearchedFiles;
        }

        /// <summary>
        /// Serach for word in all sorted files
        /// </summary>
        /// <param name="searchWord"></param>
        /// <returns></returns>
        public static List<KeyValuePair<string, int>> Serach(string searchWord)
        {
            return new List<KeyValuePair<string, int>>();
        }
    }
}
